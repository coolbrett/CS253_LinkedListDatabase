import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This class operates all functionality of the Linked List Database
 * @author Brett Dale
 * @version 1.0 (9/18/2019)
 */
public class Database {

    /**Table to represent Administration */
    private Table<AttributeInterface> admin = new Table<AttributeInterface>("Admin");
    /**Table to represent Faculty */
    private Table<AttributeInterface> faculty = new Table<AttributeInterface>("Faculty");
    /**scanner to get input */
    private Scanner scanner = new Scanner(System.in);

    /**
     * Main method to run the database
     * @param args files that are passed in as program arguments
     * @param <T> Implements covariance to the main method to be able to accept any class
     *            implementing Attribute Interface
     */
    public static <T extends AttributeInterface> void main(String[] args){
        Database driver = new Database();
        if (args.length != 2){
            throw new ExceptionInInitializerError("Needs two files");
        }
        for (String file : args){
            driver.readFile(file);
        }
        driver.displayChoices();
    }

    /**
     * Displays and executes all possible choices that can be run in the Database
     */
    private void displayChoices(){
        try {
            System.out.println("\nPlease make a choice:" + "\n\t\t" + "0) Quit" + "\n\t\t" + "1) Intersect"
                    + "\n\t\t" + "2) Difference" + "\n\t\t" + "3) Union" + "\n\t\t" + "4) Select"
                    + "\n\t\t" + "5) Remove" + "\n\t\t" + "6) Print both tables");
            System.out.print(" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ");
            String temp = scanner.next();
            int i = Integer.parseInt(temp);
            if (i > 6 || i < 0){
                displayChoices();
            }
            switch (i){
                case 0:
                    System.out.println("\nGoodbye!");
                    break;
                case 1:
                    Table<AttributeInterface> intersect = this.option1();
                    System.out.println(intersect.toString());
                    displayChoices();
                    break;
                case 2:
                    Table<AttributeInterface> difference = this.option2();
                    if (!difference.isEmpty()) {
                        System.out.println(difference.toString());
                    }
                    displayChoices();
                    break;
                case 3:
                    Table<AttributeInterface> union = this.option3();
                    System.out.println(union.toString());
                    displayChoices();
                    break;
                case 4:
                    Table<AttributeInterface> select = this.option4();
                    if (!select.isEmpty()){
                        System.out.println(select.toString());
                    }
                    displayChoices();
                    break;
                case 5:
                    this.option5();
                    break;
                case 6:
                    System.out.println(faculty.toString());
                    System.out.println(admin.toString());
                    displayChoices();
                    break;
            }
        }catch (InputMismatchException e){
            displayChoices();
        }
        catch (NumberFormatException e){
            displayChoices();
        }
    }

    /**
     * This method executes if the user chooses option 1 in displayChoices(). Uses the intersect() method to return
     * the appropriate table
     * @return table appropriate to specified values from the user
     */
    private Table<AttributeInterface> option1(){
        System.out.print("Enter attribute >");
        String temp = scanner.next();
        System.out.print("Enter value >");
        String value = scanner.next();
        Table<AttributeInterface> table = faculty.intersect(temp, value, admin);
        table.setTitle("Faculty, Admin");
        for (AttributeInterface data : table){
            data.change("department", "Faculty, Admin");
        }
        return table;
    }

    /**
     * This method executes if the user chooses 2 in displayChoices(). Uses the difference() method to return
     * the appropriate table
     * @return table appropriate to specified values from the user
     */
    private Table<AttributeInterface> option2() {
        Table<AttributeInterface> table = new Table<AttributeInterface>("");
        System.out.print("Enter table (F/A) >");
        String temp = scanner.next();
        temp = temp.toUpperCase();
        if (temp.equals("F")) {
            table = faculty.difference(admin);
            table.setTitle("Faculty, Admin");
            for (AttributeInterface data : table) {
                data.change("department", "Faculty");
            }
        } else if (temp.equals("A")) {
            table = admin.difference(faculty);
            table.setTitle("Admin, Faculty");
            for (AttributeInterface data : table) {
                data.change("department", "Admin");
            }
        }
        return table;
    }

    /**
     * This method executes if the user chooses 3 in displayChoices(). Uses the union() method to return
     * the appropriate table
     * @return table appropriate to specified values from the user
     */
    private Table<AttributeInterface> option3(){
        return faculty.union(admin);
    }

    /**
     * This method executes if the user chooses 4 in displayChoices(). Uses the select() method to return
     * the appropriate table
     * @return table appropriate to specified values from the user
     */
    private Table<AttributeInterface> option4(){
        System.out.print("Enter Table (F/A) >");
        String temp = scanner.next();
        System.out.print("Enter attribute >");
        String attribute = scanner.next();
        System.out.print("Enter value >");
        String value = scanner.next();
        temp = temp.toUpperCase();
        Table<AttributeInterface> table = new Table<AttributeInterface>("");
        if (temp.equals("F")){
            table = faculty.select(attribute, value);
            table.setTitle("Faculty");
        }else if (temp.equals("A")){
            table = admin.select(attribute, value);
            table.setTitle("Admin");
        }
        return table;
    }

    /**
     * This method executes if the user chooses 5 in displayChoices(). Uses the remove() method and
     * then runs displayChoices() again until user does not choose 5.
     */
    private void option5(){
        System.out.print("Enter table (F/A) >");
        String temp = scanner.next();
        System.out.print("Enter value >");
        String value = scanner.next();
        temp = temp.toUpperCase();
        if (temp.equals("F")){
            faculty.remove(value);
            System.out.println("\n");
            displayChoices();
        }
        else if (temp.equals("A")){
            admin.remove(value);
            System.out.println("\n");
            displayChoices();
        }
    }

    /**
     * This method reads in files passed in through the program arguments and populates
     * the Admin and Faculty tables
     * @param args file passed in
     */
    private void readFile(String args) {
        try {
            File file = new File(args);
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                if (args.equals("admin.txt") || args.equals("faculty.txt")) {
                    String last = sc.next();
                    String first = sc.next();
                    String s = sc.next();
                    s = s.toUpperCase();
                    Status status = Status.UNASSIGNED;
                    status = status.determineStatus(s);
                    Person person = new Person(first, last, status);
                    String ident = sc.next();
                    String phone = sc.next();
                    String division = sc.next();
                    String years = sc.next();
                    String dpt;
                    if (args.equals("admin.txt")) {
                        dpt = "Admin";
                    } else {
                        dpt = "Faculty";
                    }
                    Employee employee = new Employee(ident, phone, division, years, person, dpt);
                    if (dpt.equals("Faculty")) {
                        this.faculty.insert(employee);
                    } else {
                        this.admin.insert(employee);
                    }
                }
            }
            sc.close();
        }catch (FileNotFoundException e){
            System.out.println("file not found");
        }
    }
}