import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Database {

    public static <T extends AttributeInterface> void main(String[] args) {
        //first 3 fields in txt files are person fields, rest is employee
        Table<T> admin = new Table<T>("Admin");
        Table<T> faculty = new Table<T>("Faculty");
        try {
            //reading the file and interpreting all data
            for (String arg : args) {
                File file = new File(arg);
                Scanner sc = new Scanner(file);
                while ((sc.hasNextLine())) {
                    if (arg.equals("admin.txt") || arg.equals("faculty.txt")) {
                        //start getting fields to build person
                        String last = sc.next();
                        String first = sc.next();
                        String s = sc.next();
                        s = s.toUpperCase();
                        Status status;
                        switch (s) {
                            case "S":
                                status = Status.SINGLE;
                                break;
                            case "W":
                                status = Status.WIDOWED;
                                break;
                            case "D":
                                status = Status.DIVORCED;
                                break;
                            default:
                                status = Status.MARRIED;
                                break;
                        }
                        Person person = new Person(first, last, status);
                        //start getting fields to build Employee
                        String ident = sc.next();
                        String phone = sc.next();
                        String division = sc.next();
                        String years = sc.next();
                        String dpt;
                        if (arg.equals("admin.txt")) {
                            dpt = "Admin";
                        } else {
                            dpt = "Faculty";
                        }
                        Employee employee = new Employee(ident, phone, division, years, person, dpt);
                        //System.out.println(employee.toString());
                        if (dpt.equals("Faculty")) {
                            faculty.insert((T) employee);
                        } else {
                            admin.insert((T) employee);
                        }
                    }
                }
                //close current scanner before making new one
                sc.close();
            }

            //connect to keyboard and display options
            Scanner scanner = new Scanner(System.in);
            //while loop may have to go here for certain options
            System.out.println("Please make a choice:" + "\n\t\t" + "0) Quit" + "\n\t\t" + "1) Intersect"
                    + "\n\t\t" + "2) Difference" + "\n\t\t" + "3) Union" + "\n\t\t" + "4) Select"
                    + "\n\t\t" + "5) Remove" + "\n\t\t" + "6) Print both tables");
            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ");
            //calling scanner.next methods stops program for input
            int i = scanner.nextInt();
            
            switch (i){
                case 0:
                    System.out.println("\nGoodbye!");
                    break;
                case 1:
                    System.out.println("case 1 works");
                    break;
            }

        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        } catch (InputMismatchException e){
            System.out.print("");
        }
    }
}
