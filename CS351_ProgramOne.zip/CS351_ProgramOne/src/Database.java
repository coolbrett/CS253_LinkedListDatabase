import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Database {

    public static <T extends AttributeInterface> void main(String[] args) {
        //first 3 fields in txt files are person fields, rest is employee
        Table<T> admin = new Table<T>("Admin");
        Table<T> faculty = new Table<T>("Faculty");
        try {
            for (String arg : args) {
                File file = new File(arg);
                Scanner sc = new Scanner(file);
                if (arg.equals("admin.txt")) {
                    String last = sc.next();
                    String first = sc.next();
                    String s = sc.next();
                    s = s.toUpperCase();
                    Status status;
                    if (s.equals("S")) {
                        status = Status.SINGLE;
                    } else if (s.equals("W")) {
                        status = Status.MARRIED;
                    } else if (s.equals("D")) {
                        status = Status.DIVORCED;
                    } else {
                        status = Status.MARRIED;
                    }
                    Person person = new Person(first, last, status);
                    Employee employee;

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        }
    }
}
