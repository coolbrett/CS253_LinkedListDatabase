import java.io.File;
import java.io.FileNotFoundException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Database {

    /**Table to represent Administration */
    private Table<AttributeInterface> admin = new Table<AttributeInterface>("Admin");
    /**Table to represent Faculty */
    private Table<AttributeInterface> faculty = new Table<AttributeInterface>("Faculty");
    /**scanner to get input */
    private Scanner scanner = new Scanner(System.in);

    public static <T extends AttributeInterface> void main(String[] args){
        Database driver = new Database();
        //read both files in and interpret data
        for (String file : args){
            driver.readFile(file);
        }
        driver.displayChoices();
    }

    private void displayChoices(){
        try {
            System.out.println("Please make a choice:" + "\n\t\t" + "0) Quit" + "\n\t\t" + "1) Intersect"
                    + "\n\t\t" + "2) Difference" + "\n\t\t" + "3) Union" + "\n\t\t" + "4) Select"
                    + "\n\t\t" + "5) Remove" + "\n\t\t" + "6) Print both tables");
            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ");
            //calling scanner.next methods stops program for input
            int i = scanner.nextInt();
            switch (i){
                //cases that involve more keyboard input need to be done in this method to avoid multiple scanners
                case 0:
                    System.out.println("\nGoodbye!");
                    break;
                case 1:
                    //intersect

                    break;
                case 2:
                    //difference
                    break;
                case 3:
                    //union
                    break;
                case 4:
                    //select
                    break;
                case 5:
                    //remove
                    break;
                case 6:
                    System.out.println(faculty.toString());
                    System.out.println(admin.toString());
                    break;
            }
        }catch (InputMismatchException e){
            System.out.println("");
        }
    }

    private void option1(){

    }

    //38 lines :)
    private void readFile(String args) {
        try {
            File file = new File(args);
            Scanner sc = new Scanner(file);
            while (sc.hasNextLine()) {
                if (args.equals("admin.txt") || args.equals("faculty.txt")) {
                    String last = sc.next();
                    String first = sc.next();
                    String s = sc.next();
                    s = s.toUpperCase();
                    Status status = Status.UNASSIGNED;
                    status = status.determineStatus(s);
                    Person person = new Person(first, last, status);
                    String ident = sc.next();
                    String phone = sc.next();
                    String division = sc.next();
                    String years = sc.next();
                    String dpt;
                    if (args.equals("admin.txt")) {
                        dpt = "Admin";
                    } else {
                        dpt = "Faculty";
                    }
                    Employee employee = new Employee(ident, phone, division, years, person, dpt);
                    System.out.println(employee.toString());
                    if (dpt.equals("Faculty")) {
                        this.faculty.insert(employee);
                    } else {
                        this.admin.insert(employee);
                    }
                }
            }
            sc.close();
        }catch (FileNotFoundException e){
            System.out.println("file not found");
        }
    }

   /** public static <T extends AttributeInterface> void badmain(String[] args) {
        try {
            for (String arg : args) {
                File file = new File(arg);
                Scanner sc = new Scanner(file);
                while ((sc.hasNextLine())) {
                    if (arg.equals("admin.txt") || arg.equals("faculty.txt")) {
                        String last = sc.next();
                        String first = sc.next();
                        String s = sc.next();
                        s = s.toUpperCase();
                        Status status;
                        switch (s) {
                            case "S":
                                status = Status.SINGLE;
                                break;
                            case "W":
                                status = Status.WIDOWED;
                                break;
                            case "D":
                                status = Status.DIVORCED;
                                break;
                            default:
                                status = Status.MARRIED;
                                break;
                        }
                        Person person = new Person(first, last, status);
                        String ident = sc.next();
                        String phone = sc.next();
                        String division = sc.next();
                        String years = sc.next();
                        String dpt;
                        if (arg.equals("admin.txt")) {
                            dpt = "Admin";
                        } else {
                            dpt = "Faculty";
                        }
                        Employee employee = new Employee(ident, phone, division, years, person, dpt);
                       /** if (dpt.equals("Faculty")) {
                            faculty.insert((T) employee);
                        } else {
                            admin.insert((T) employee);
                        } */
               /** sc.close();
            //connect to keyboard and display options
            Scanner scanner = new Scanner(System.in);
            //while loop may have to go here for certain options
            System.out.println("Please make a choice:" + "\n\t\t" + "0) Quit" + "\n\t\t" + "1) Intersect"
                    + "\n\t\t" + "2) Difference" + "\n\t\t" + "3) Union" + "\n\t\t" + "4) Select"
                    + "\n\t\t" + "5) Remove" + "\n\t\t" + "6) Print both tables");
            System.out.print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ");
            //calling scanner.next methods stops program for input
            int i = scanner.nextInt();
            
            switch (i){
                case 0:
                    System.out.println("\nGoodbye!");
                    break;
                case 1:

                    break;
            }

        } catch (FileNotFoundException e) {
            System.out.println("file not found");
        } catch (InputMismatchException e){
            System.out.print("");
        }
*/
}