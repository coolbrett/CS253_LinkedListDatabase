public class Person {
    /**
     * First name
     */
    private String first;
    /**
     * Last name
     */
    private String last;
    /**
     * Marital Status
     */
    private Status status;

    public Person(String first, String last, Status status) {
        this.first = first;
        this.last = last;
        this.status = status;
    }

    public String getWholeName() {
        return this.first + " " + this.last;
    }

    public void setFirst(String first) {
        this.first = first;
    }

    public String getFirst() {
        return this.first;
    }

    public void setLast(String last) {
        this.last = last;
    }

    public String getLast() {
        return last;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return this.status;
    }

    public boolean equals(Person person){
        if (this.first.equals(person.first) && this.last.equals(person.last) && this.status == person.status){
            return true;
        }else{
            return false;
        }
    }
}