import java.util.Iterator;
public class Table<T extends AttributeInterface> implements Iterable<T> {

    /** Size of Table */
    private int size = 0;
    /** First record in the table */
    private Node head;
    /** Label for the table */
    private String title;

    public Table(String title){
        this.head = null;
        this.title = title;
    }

    public Table(Table<T> list) {
        if (list == null) {
            throw new IllegalArgumentException("constructor; Table has/is null");
        } else {
            for (T data : list) {
                this.insert(data);
            }
        }
    }

    /**
     * Creates a new table comprised of nodes in this table, but not in table
     * @param table table being passed in
     * @return returns table that has all nodes not in table
     */
    // FIXME: 9/9/2019 title of Table may need to call a department method??
    public Table<T> difference(Table<T> table){
        if (table == null){
            throw new IllegalArgumentException("difference; null table");
        }else {
            Table<T> temp = new Table<T>(this);
            Table<T> other = new Table<T>("");
            for (T data : temp) {
                if (!table.contains(data)) {
                    other.insert(data);
                }
            }
            return other;
        }
    }

    /**
     * Creates a new table comprised of nodes having a value for a specific attribute, created from two tables.
     * @param attribute attribute to search for in nodes
     * @param value value to possess to be selected
     * @param table table to be searched
     * @return table that has nodes that contain specific values
     */
    // TODO: 9/9/2019 write select method then use it here
    public Table<T> intersect(String attribute, String value, Table<T> table){
        if (attribute == null || value == null || table == null){
            throw new IllegalArgumentException("intersect; null arguments");
        }
        else {
            Table<T> temp = new Table<T>(this);
            //admin
            table = table.select(attribute, value);
            //faculty
            temp = temp.select(attribute, value);
            // FIXME: 9/18/2019 Duplicates make it through
            for (T data : table){
                if (!temp.contains(data)) {
                    data.change("department", "Faculty, Admin");
                    temp.insert(data);
                }
            }
            return temp;
        }
    }

    /**
     * Creates a new table comprised of nodes having a value for a specific attribute
     * @param attribute attribute to search
     * @param value value to find in attribute
     * @return
     */
    // TODO: 9/10/2019  if this method fails, check the check() method in Employee
    public Table<T> select(String attribute, String value) {
        //nodes that have specific value go in new table
        if (attribute == null || value == null){
            throw new IllegalArgumentException("select; null argument");
        }else {
            Table<T> temp = new Table<T>("Select");
            for (T node : this) {
                if (node.check(attribute, value)) {
                    temp.insert(node);
                }
            }
            return temp;
        }
    }

    /**
     * Creates a new table comprised of all nodes that occur in both tables
     * @param table table to compare to
     * @return table that has nodes that are in both this and table passed in
     */
    // TODO: 9/10/2019 may need to be more specific with equals method
    public Table<T> union(Table<T> table) {
        if (table == null) {
            throw new IllegalArgumentException("union; null table");
        } else {
            Table<T> temp = new Table<T>("Faculty, Admin");
            for (T data : this){
                temp.insert(data);
            }
            for (T data : table){
                if(!temp.contains(data)){
                    temp.insert(data);
                }
            }
            return temp;
        }
    }


    /**
     * This method gets the Node at the desired index
     *
     * @param index position of desired Node
     * @return Node temp is the Node that is found at desired index
     */
    private Node getNodeAt(int index) {
        Node temp = head;
        if (index >= this.size) {
            throw new IllegalArgumentException("getNode; index too far");
        } else {
            if (index != 0) {
                for (int i = 0; i < index; i++) {
                    temp = temp.next;
                }
            }
        }
        return temp;
    }

    private T getDataAt(int index) {
        Node temp = this.getNodeAt(index);
        T tempData = (T) temp.getData();
        return tempData;
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * More formally, adds the specified element q to this set if the set contains no element q2
     * such that q != null &amp;&amp; q.equals(q2). If this set already contains the element,
     * the call leaves the set unchanged and returns false. In combination with the restriction on
     * constructors, this ensures that sets never contain duplicate elements.
     *
     * @param element to be added to this set.
     * @return true if the set did not already contain the element.
     * @throws IllegalArgumentException if the element to be added is null.
     */
    public void insert(T element) {
        if (element == null) {
            throw new IllegalArgumentException("insert; null element");
        } else {
            if (this.isEmpty()) {
                this.head = new Node(element);
                this.size++;
            } else {
                if (!(this.contains(element))) {
                    Node temp = this.getNodeAt(this.size - 1);
                    temp.next = new Node(element);
                    this.size++;
                }
            }
        }
    }

    /**
     * Clears all data from this set.
     */
    public void clear() {
        this.head = null;
    }

    /**
     * Determine if a specific object is in the set.
     *
     * @param element object to search for
     * @return true if the object is in the set, false otherwise.
     * @throws IllegalArgumentException generated if the object to search for is null.
     */
    public boolean contains(T element) {
        boolean status = false;
        if (element == null) {
            throw new IllegalArgumentException("contains; null element");
        } else {
            for (T data : this) {
                if (data.equals(element)) {
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Returns an iterator over the elements in this collection.  There are no
     * guarantees concerning the order in which the elements are returned
     * (unless this collection is an instance of some class that provides a
     * guarantee).
     *
     * @return an {@code Iterator} over the elements in this collection
     */
    public Iterator<T> iterator() {
        return new LinkedIterator();
    }

    /**
     * Determine if this set contains no elements.
     *
     * @return true if this set contains no elements, false otherwise.
     */
    public boolean isEmpty() {
        return this.head == null;
    }

    /**
     * Removes the node matching id
     * @param id id to be checked for to remove
     */
    public void remove(String id) {
        if (id == null) {
            throw new IllegalArgumentException("remove; id is null");
        }

        if (this.head.data.check("id", id)) {
            this.head = this.head.next;
            this.size--;
        }

        Node temp = this.head;
        while (temp.next != null) {
            if (temp.next.data.check("id", id)) {
                temp.next = temp.next.next;
                size--;
            } else {
                temp = temp.next;
            }
        }
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     *
     * @return the number of elements in this set (tis cardinality).
     */
    public int size() {
        return this.size;
    }

    /**
     * Returns true if this set contains all of the elements of the specified collection. If the
     * specified collection is also a set, this method returns true if it is a subset of this set.
     *
     * @param list collection to be checked for containment in this set.
     * @return true if this set contains all the elements of the specified collection.
     * @throws IllegalArgumentException If the specified collection is null or contains any null
     *                                  elements.
     */
    public boolean containsAll(Table<T> list) {

        boolean status = true;
        if (list == null) {
            status = false;
            throw new IllegalArgumentException("containsAll; null list");
        } else {
            for (Object data : list) {
                if (!(this.contains((T) data))) {
                    status = false;
                }
            }
        }
        return status;
    }

    @Override
    public boolean equals(Object other) {
        boolean status = false;
        if (other instanceof Table) {
            if (((Table) other).size() == this.size()) {
                if (this.containsAll((Table) other)) {
                    status = true;
                }
            }
        }
        return status;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        String part = "=========================" + this.title + "=========================\n";
        str.append("\n" + part);
        for (T data : this){
            str.append(data.toString());
        }
        str.append(part);
        return str.toString();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**************************************************************************************/

    private class Node {
        private T data;
        private Node next;

        private Node(T data) {
            this.data = data;
            this.next = null;
        }

        private Node(T data, Node node) {
            this.data = data;
            this.next = node;
        }

        private T getData() {
            return this.data;
        }

        @Override
        public String toString() {
            return this.data.toString();
        }
    }

    /*************************************************************************************/

    private class LinkedIterator implements Iterator<T> {

        private Node node;

        private LinkedIterator() {
            this.node = head;
        }

        public boolean hasNext() {
            return node != null;
        }

        public T next() {
            T hold = (T) node.data;
            node = node.next;
            return hold;
        }
    }
}