public enum Status {

    SINGLE("S"),
    WIDOWED("W"),
    DIVORCED("D"),
    MARRIED("M");

    private final String status;

    Status(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return this.status;
    }
}