public enum Status {

    SINGLE("Single"),
    WIDOWED("Widowed"),
    DIVORCED("Divorced"),
    MARRIED("Married"),
    UNASSIGNED("Unassigned");

    private final String status;

    Status(String status) {
        this.status = status;
    }

    public Status determineStatus(String s){
        Status temp;
        switch (s){
            case "M":
                temp = Status.MARRIED;
                break;
            case "W":
                temp = Status.WIDOWED;
                break;
            case "D":
                temp = Status.DIVORCED;
                break;
            default:
                temp = Status.SINGLE;
                break;
        }
        return temp;
    }

    @Override
    public String toString() {
        return this.status;
    }
}