/**
 * This class builds Employee objects that possess fields that Employees typically have.
 * @author Brett Dale
 * @version 1.0 (9/14/2019)
 */
public class Employee implements AttributeInterface {

    /**
     * Identification number
     */
    private String id;
    /**
     * Phone number
     */
    private String phone;
    /**
     * Division within the institution
     */
    private String division;
    /**
     * Number of years employed
     */
    private String years;
    /**
     * Personal information
     */
    private Person person;
    /**
     * Current department or classification
     */
    private String department;

    /**
     * Constructor to build an Employee
     *
     * @param id         ID number of Employee
     * @param phone      Phone number of Employee
     * @param division   Division Employee is in
     * @param years      Years Employee has spent at company
     * @param person     Person object for person so that they have name and marital status
     * @param department Department Employee works in
     */
    public Employee(String id, String phone, String division, String years, Person person, String department) {
        this.id = id;
        this.phone = phone;
        this.division = division;
        this.years = years;
        this.person = person;
        this.department = department;
    }

    public Person getPerson() {
        return person;
    }

    public String getDepartment() {
        return department;
    }

    public String getDivision() {
        return division;
    }

    public String getId() {
        return id;
    }

    public String getPhone() {
        return phone;
    }

    public String getYears() {
        return years;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setYears(String years) {
        this.years = years;
    }

    /**
     * Check to see if a record has an attribute containing a specific value.
     *
     * @param attribute
     * @param value
     */
    @Override
    public boolean check(String attribute, String value) {
        attribute = attribute.toLowerCase();
        if (attribute.equals("id")) {
            if (value.equals(this.id)) {
                return true;
            }
        } else if (attribute.equals("phone")) {
            if (value.equals(this.phone)) {
                return true;
            }
        } else if (attribute.equals("division")) {
            if (value.equals(this.division)) {
                return true;
            }
            // TODO: 9/14/2019 change this to check for each attribute of person not all 
        } else if (attribute.equals("person")) {
            if (value.equals(this.getPerson().getWholeName())) {
                return true;
            }
        } else if (attribute.equals("years")) {
            if (value.equals(this.years)) {
                return true;
            }
        } else if (attribute.equals("department")) {
            if (value.equals(this.department)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Change the value of a specific attribute.
     *
     * @param attribute attribute to go into
     * @param value value to place in the attribute
     */
    @Override
    public boolean change(String attribute, String value) {
        if (this.check(attribute, value)) {
            attribute = attribute.toLowerCase();
            if (attribute.equals("id")) {
                this.id = value;
                return true;
            } else if (attribute.equals("phone")) {
                this.phone = value;
                return true;
            } else if (attribute.equals("division")) {
                this.division = value;
                return true;
            } else if (attribute.equals("department")) {
                this.department = value;
                return true;
                // TODO: 9/14/2019 change this to access only one attribute of Person not all 
            } else if (attribute.equals("name")) {
                String[] hold = value.split(" ", 1);
                if (hold.length >= 2) {
                    person.setFirst(hold[0]);
                    person.setLast(hold[1]);
                    return true;
                }
            } else if (attribute.equals("years")) {
                this.years = value;
                return true;
            }
        }
        return false;
    }

    /**
     * Make a deep copy. Do NOT use clone() or a copy constructor.
     */
    @Override
    public Employee makeCopy() {
        return new Employee(this.id, this.phone, this.division, this.years, this.person, this.department);
    }

    @Override
    public String toString(){
        return "Employee(" + this.id + ") : " + this.getPerson().getLast() + ", " + this.getPerson().getFirst()
                + ": " + this.getPerson().getStatus() + "\n\t\t" + "Record: " + this.years
                + " years in division [" + this.division + "] -- Dept: " + this.department
                + "\n--------------------------------------------------------------";
    }
    //can two employees have same ID but different fields?
    public boolean equals(Employee employee){
        if (employee.id.equals(this.id)){
            return true;
        }
        return false;
    }
}