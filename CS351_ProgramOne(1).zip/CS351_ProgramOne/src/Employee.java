public class Employee implements AttributeInterface {

    /**
     * Identification number
     */
    private String id;
    /**
     * Phone number
     */
    private String phone;
    /**
     * Division within the institution
     */
    private String division;
    /**
     * Number of years employed
     */
    private String years;
    /**
     * Personal information
     */
    private Person person;
    /**
     * Current department or classification
     */
    private String department;

    /**
     * Constructor to build an Employee
     *
     * @param id         ID number of Employee
     * @param phone      Phone number of Employee
     * @param division   Division Employee is in
     * @param years      Years Employee has spent at company
     * @param person     Person object for person so that they have name and marital status
     * @param department Department Employee works in
     */
    public Employee(String id, String phone, String division, String years, Person person, String department) {
        this.id = id;
        this.phone = phone;
        this.division = division;
        this.years = years;
        this.person = person;
        this.department = department;
    }

    public Person getPerson() {
        return person;
    }

    public String getDepartment() {
        return department;
    }

    public String getDivision() {
        return division;
    }

    public String getId() {
        return id;
    }

    public String getPhone() {
        return phone;
    }

    public String getYears() {
        return years;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setDivision(String division) {
        this.division = division;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setYears(String years) {
        this.years = years;
    }

    /**
     * Check to see if a record has an attribute containing a specific value.
     *
     * @param attribute
     * @param value
     */
    @Override
    public boolean check(String attribute, String value) {
        attribute = attribute.toLowerCase();
        if (attribute.equals("id")) {
            if (value.equals(this.id)) {
                return true;
            }
        } else if (attribute.equals("phone")) {
            if (value.equals(this.phone)) {
                return true;
            }
        } else if (attribute.equals("division")) {
            if (value.equals(this.division)) {
                return true;
            }
        } else if (attribute.equals("name")) {
            if (value.equals(person.getWholeName())) {
                return true;
            }
        } else if (attribute.equals("years")) {
            if (value.equals(this.years)) {
                return true;
            }
        } else if (attribute.equals("department")) {
            if (value.equals(this.department)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Change the value of a specific attribute.
     *
     * @param attribute
     * @param value
     */
    @Override
    public boolean change(String attribute, String value) {
        if (this.check(attribute, value)) {
            attribute = attribute.toLowerCase();
            if (attribute.equals("id")) {
                this.id = value;
                return true;
            } else if (attribute.equals("phone")) {
                this.phone = value;
                return true;
            } else if (attribute.equals("division")) {
                this.division = value;
                return true;
            } else if (attribute.equals("department")) {
                this.department = value;
                return true;
            } else if (attribute.equals("name")) {
                String[] hold = value.split(" ", 1);
                if (hold.length >= 2) {
                    person.setFirst(hold[0]);
                    person.setLast(hold[1]);
                    return true;
                }
            } else if (attribute.equals("years")) {
                this.years = value;
                return true;
            }
        }
        return false;
    }

    /**
     * Make a deep copy. Do NOT use clone() or a copy constructor.
     */
    @Override
    public Employee makeCopy() {
        Employee temp = new Employee(this.id, this.phone, this.division, this.years, this.person, this.department);
        return temp;
    }

    /****************************************************************************************/

    private class Person {
        /**
         * First name
         */
        private String first;
        /**
         * Last name
         */
        private String last;
        /**
         * Marital Status
         */
        private Status status;

        public Person(String first, String last, Status status) {
            this.first = first;
            this.last = last;
            this.status = status;
        }

        public String getWholeName() {
            return this.first + " " + this.last;
        }

        public void setFirst(String first) {
            this.first = first;
        }

        public String getFirst() {
            return this.first;
        }

        public void setLast(String last) {
            this.last = last;
        }

        public String getLast() {
            return last;
        }

        public void setStatus(Status status) {
            this.status = status;
        }

        public Status getStatus() {
            return this.status;
        }
    }

    private enum Status {

        SINGLE("S"),
        WIDOWED("W"),
        DIVORCED("D"),
        MARRIED("M");

        private final String status;

        Status(String status) {
            this.status = status;
        }

        @Override
        public String toString() {
            return this.status;
        }
    }
}