import java.util.Iterator;

/**
 * This class sets up Table objects to build Linked List style data structures
 * @param <T> Generic type to allow all objects into the table that implement AttributeInterface
 * @author Brett Dale
 * @version 1.0 (9/20/2019)
 */
public class Table<T extends AttributeInterface> implements Iterable<T> {

    /** Size of Table */
    private int size = 0;
    /** First record in the table */
    private Node head;
    /** Label for the table */
    private String title;

    /**
     * Constructor to set up default Table
     * @param title title of Table
     */
    public Table(String title){
        this.head = null;
        this.title = title;
    }

    /**
     * Constructor to build Table off of passed in list
     * @param list list to build new Table off of
     */
    private Table(Table<T> list) {
        if (list == null) {
            throw new IllegalArgumentException("constructor; Table has/is null");
        } else {
            for (T data : list) {
                this.insert(data);
            }
        }
    }

    /**
     * Creates a new table comprised of nodes in this table, but not in table
     * @param table table being passed in
     * @return returns table that has all nodes not in table
     */
    public Table<T> difference(Table<T> table){
        if (table == null){
            throw new IllegalArgumentException("difference; null table");
        }else {
            Table<T> temp = new Table<>(this);
            Table<T> other = new Table<>("");
            for (T data : temp) {
                if (!table.contains(data)) {
                    other.insert(data);
                }
            }
            return other;
        }
    }

    /**
     * Creates a new table comprised of nodes having a value for a specific attribute, created from two tables.
     * @param attribute attribute to search for in nodes
     * @param value value to possess to be selected
     * @param table table to be searched
     * @return table that has nodes that contain specific values
     */
    public Table<T> intersect(String attribute, String value, Table<T> table){
        if (attribute == null || value == null || table == null){
            throw new IllegalArgumentException("intersect; null arguments");
        }
        else {
            Table<T> temp = new Table<>(this);
            table = table.select(attribute, value);
            temp = temp.select(attribute, value);
            for (T data : table){
                if (!temp.contains(data)) {
                    data.change("department", "Faculty, Admin");
                    temp.insert(data);
                }
            }
            return temp;
        }
    }

    /**
     * Creates a new table comprised of nodes having a value for a specific attribute
     * @param attribute attribute to search
     * @param value value to find in attribute
     * @return Table containing only the nodes that have specified values
     */
    public Table<T> select(String attribute, String value) {
        if (attribute == null || value == null){
            throw new IllegalArgumentException("select; null argument");
        }else {
            Table<T> temp = new Table<T>("Select");
            for (T node : this) {
                if (node.check(attribute, value)) {
                    temp.insert(node);
                }
            }
            return temp;
        }
    }

    /**
     * Creates a new table comprised of all nodes that occur in both tables
     * @param table table to compare to
     * @return table that has nodes that are in both this and table passed in
     */
    public Table<T> union(Table<T> table) {
        if (table == null) {
            throw new IllegalArgumentException("union; null table");
        } else {
            Table<T> temp = new Table<>("Faculty, Admin");
            for (T data : this){
                if (table.contains(data)){
                    data.change("department", "Faculty, Admin");
                }
                temp.insert(data);
            }
            for (T data : table){
                if(!temp.contains(data)){
                    temp.insert(data);
                }
            }
            return temp;
        }
    }


    /**
     * This method gets the Node at the desired index
     *
     * @param index position of desired Node
     * @return Node temp is the Node that is found at desired index
     */
    private Node getNodeAt(int index) {
        Node temp = head;
        if (index >= this.size) {
            throw new IllegalArgumentException("getNode; index too far");
        } else {
            if (index != 0) {
                for (int i = 0; i < index; i++) {
                    temp = temp.next;
                }
            }
        }
        return temp;
    }

    /**
     * This method inserts a node containing the passed in data into the table called upon
     * @param data data to be put into new node that goes into table
     */
    public void insert(T data) {
        if (data == null) {
            throw new IllegalArgumentException("insert; null element");
        } else {
            if (this.isEmpty()) {
                this.head = new Node(data);
                this.size++;
            } else {
                if (!(this.contains(data))) {
                    Node temp = this.getNodeAt(this.size - 1);
                    temp.next = new Node(data);
                    this.size++;
                }
            }
        }
    }

    /**
     * Determine if a specific object is in the table.
     *
     * @param element object to search for
     * @return true if the object is in the table, false otherwise.
     * @throws IllegalArgumentException generated if the object to search for is null.
     */
    private boolean contains(T element) {
        boolean status = false;
        if (element == null) {
            throw new IllegalArgumentException("contains; null element");
        } else {
            for (T data : this) {
                if (data.equals(element)) {
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Returns an iterator over the elements in this table.  There are no
     * guarantees concerning the order in which the elements are returned
     *
     * @return an {@code Iterator} over the elements in this collection
     */
    public Iterator<T> iterator() {
        return new LinkedIterator();
    }

    /**
     * Determine if this table contains no elements.
     *
     * @return true if this table contains no elements, false otherwise.
     */
    public boolean isEmpty() {
        return this.head == null;
    }

    /**
     * Removes the node matching id
     * @param id id to be checked for to remove
     */
    public void remove(String id) {
        if (id == null) {
            throw new IllegalArgumentException("remove; id is null");
        }

        if (this.head.data.check("id", id)) {
            this.head = this.head.next;
            this.size--;
        }

        Node temp = this.head;
        while (temp.next != null) {
            if (temp.next.data.check("id", id)) {
                temp.next = temp.next.next;
                size--;
            } else {
                temp = temp.next;
            }
        }
    }

    /**
     * Returns the number of elements in this table (its cardinality).
     *
     * @return the number of elements in this table (tis cardinality).
     */
    private int size() {
        return this.size;
    }

    /**
     * Returns true if this table contains all of the elements of the specified table. If the
     * specified table is also a table, this method returns true if it is a table of this table.
     *
     * @param list table to be checked for containment in this table.
     * @return true if this table contains all the elements of the specified table.
     * @throws IllegalArgumentException If the specified table is null or contains any null
     *                                  elements.
     */
    private boolean containsAll(Table<T> list) {

        boolean status = true;
        if (list == null) {
            throw new IllegalArgumentException("containsAll; null list");
        } else {
            for (Object data : list) {
                if (!(this.contains((T) data))) {
                    status = false;
                }
            }
        }
        return status;
    }

    /**
     * Equals method for Table objects.
     * @param other table to be compared to this
     * @return true if they are equal, false otherwise
     */
    @Override
    public boolean equals(Object other) {
        boolean status = false;
        if (other instanceof Table) {
            if (((Table) other).size() == this.size()) {
                if (this.containsAll((Table) other)) {
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Displays message appropriate for Table objects
     * @return message displaying Table object data
     */
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        String part = "=========================" + this.title + "=========================\n";
        str.append("\n").append(part);
        for (T data : this){
            str.append(data.toString());
        }
        str.append(part);
        return str.toString();
    }

    /**
     * Setter method for title field of table
     * @param title title to be set to title field
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**************************************************************************************/

    /**
     * Class to build Nodes for Table
     */
    private class Node {
        /**
         * field for data
         */
        private T data;
        /**
         * field for Nodes to point
         */
        private Node next;

        /**
         * Default constructor for Nodes
         * @param data data to place in Node
         */
        private Node(T data) {
            this.data = data;
            this.next = null;
        }

        /**
         * Constructor to build nodes pointing to another node
         * @param data data to place in Node
         * @param node node to point to
         */
        private Node(T data, Node node) {
            this.data = data;
            this.next = node;
        }

        /**
         * Displays data from Node
         * @return message containing data from Node
         */
        @Override
        public String toString() {
            return this.data.toString();
        }
    }

    /*************************************************************************************/

    /**
     * Class to build Iterator capable of going through a Linked List style data structure
     */
    private class LinkedIterator implements Iterator<T> {

        /**
         * Field for node to start
         */
        private Node node;

        /**
         * Method to set node field to start of list
         */
        private LinkedIterator() {
            this.node = head;
        }

        /**
         * Method to see if list has another node
         * @return true if there is another node, false otherwise
         */
        public boolean hasNext() {
            return node != null;
        }

        /**
         * Method to get next Node
         * @return next Node
         */
        public T next() {
            T hold = node.data;
            node = node.next;
            return hold;
        }
    }
}