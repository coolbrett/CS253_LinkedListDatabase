/**
 * This enumeration creates all possible Marital statuses + an Unassigned enum for initialization purposes
 * @author Brett Dale
 * @version 1.0 (9-20-2019)
 */
public enum Status {

    SINGLE("Single"),
    WIDOWED("Widowed"),
    DIVORCED("Divorced"),
    MARRIED("Married"),
    UNASSIGNED("Unassigned");

    /**
     * field for String version of each enumeration
     */
    private final String status;

    /**
     * Constructor for Status objects
     * @param status status to be set to object
     */
    Status(String status) {
        this.status = status;
    }

    /**
     * This method gets passed in a string and returns the status associated with that string
     * @param s string to be converted
     * @return status that is converted from string
     */
    public Status determineStatus(String s){
        Status temp;
        s = s.toUpperCase();
        switch (s){
            case "M":
                temp = Status.MARRIED;
                break;
            case "W":
                temp = Status.WIDOWED;
                break;
            case "D":
                temp = Status.DIVORCED;
                break;
            default:
                temp = Status.SINGLE;
                break;
        }
        return temp;
    }

    /**
     * Displays message that represents the Status enumeration it is set to
     * @return message that represents enumeration
     */
    @Override
    public String toString() {
        return this.status;
    }
}