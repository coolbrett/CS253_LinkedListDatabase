/**
 * This class builds Employee objects that possess fields that Employees typically have.
 * @author Brett Dale
 * @version 1.0 (9/14/2019)
 */
public class Employee implements AttributeInterface {

    /**
     * Identification number
     */
    private String id;
    /**
     * Phone number
     */
    private String phone;
    /**
     * Division within the institution
     */
    private String division;
    /**
     * Number of years employed
     */
    private String years;
    /**
     * Personal information
     */
    private Person person;
    /**
     * Current department or classification
     */
    private String department;

    /**
     * Constructor to build an Employee
     *
     * @param id         ID number of Employee
     * @param phone      Phone number of Employee
     * @param division   Division Employee is in
     * @param years      Years Employee has spent at company
     * @param person     Person object for person so that they have name and marital status
     * @param department Department Employee works in
     */
    public Employee(String id, String phone, String division, String years, Person person, String department) {
        this.id = id;
        this.phone = phone;
        this.division = division;
        this.years = years;
        this.person = person;
        this.department = department;
    }

    /**
     * Getter method for Person object
     * @return Person object
     */
    private Person getPerson() {
        return person;
    }

    /**
     * Check to see if a record has an attribute containing a specific value.
     * @param attribute attribute to look into
     * @param value value to check for in given attribute
     */
    @Override
    public boolean check(String attribute, String value) {
        attribute = attribute.toLowerCase();
        if (attribute.equals("id")) {
            return value.equals(this.id);
        } else if (attribute.equals("phone")) {
            return value.equals(this.phone);
        } else if (attribute.equals("division")) {
            return value.equals(this.division);
        } else if (attribute.equals("firstname")) {
            return value.equals(this.person.getFirst());
        } else if (attribute.equals("lastname")){
            return value.equals(this.person.getLast());
        } else if (attribute.equals("years")) {
            return value.equals(this.years);
        } else if (attribute.equals("department")) {
            return value.equals(this.department);
        } else if (attribute.equals("status")){
            Status stat = Status.UNASSIGNED;
            stat = stat.determineStatus(value);
            if (stat == this.person.getStatus()){
                return true;
            }
        }
        return false;
    }

    /**
     * Change the value of a specific attribute.
     * @param attribute attribute to go into
     * @param value value to place in the attribute
     */
    @Override
    public boolean change(String attribute, String value) {
        attribute = attribute.toLowerCase();
        if (attribute.equals("id")) {
            this.id = value;
            return true;
        } else if (attribute.equals("phone")) {
            this.phone = value;
            return true;
        } else if (attribute.equals("division")) {
            this.division = value;
            return true;
        } else if (attribute.equals("department")) {
            this.department = value;
            return true;
        } else if (attribute.equals("firstname")) {
            this.person.setFirst(value);
            return true;
        } else if (attribute.equals("lastname")){
            this.person.setLast(value);
            return true;
        } else if (attribute.equals("status")){
            Status stat = Status.UNASSIGNED;
            value = value.toUpperCase();
            stat = stat.determineStatus(value);
            this.getPerson().setStatus(stat);
            return true;
        } else if (attribute.equals("years")) {
            this.years = value;
            return true;
        }
        return false;
    }

    /**
     * Make a deep copy. Do NOT use clone() or a copy constructor.
     */
    @Override
    public Employee makeCopy() {
        return new Employee(this.id, this.phone, this.division, this.years, this.person, this.department);
    }

    /**
     * Displays nicely formatted message for Employee objects
     * @return String containing all appropriate
     */
    @Override
    public String toString(){
        return "Employee(" + this.id + ") : " + this.getPerson().getLast() + ", " + this.getPerson().getFirst()
                + ": " + this.getPerson().getStatus() + "\n\t\t" + "Record: " + this.years
                + " years in division [" + this.division + "] -- Dept: " + this.department
                + "\n--------------------------------------------------------------\n";
    }

    /**
     * Checks for equality between two employees
     * @param employee object to check equality for
     * @return returns true if equal, false otherwise
     */
    public boolean equals(Object employee){
        if (employee instanceof Employee) {
            Employee temp = (Employee) employee;
            return temp.id.equals(this.id);
        }
        return false;
    }
}