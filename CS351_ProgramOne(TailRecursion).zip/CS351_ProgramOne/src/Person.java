/**
 * This class builds all Person objects and gives them fields
 * @author Brett Dale
 * @version 1.0 (9/19/19)
 */
public class Person {
    /**
     * First name
     */
    private String first;
    /**
     * Last name
     */
    private String last;
    /**
     * Marital Status
     */
    private Status status;

    /**
     * Constructor for Person objects
     * @param first first name
     * @param last last name
     * @param status Marital status
     */
    public Person(String first, String last, Status status) {
        this.first = first;
        this.last = last;
        this.status = status;
    }

    /**
     * Setter method for first name
     * @param first first name to be set
     */
    public void setFirst(String first) {
        this.first = first;
    }

    /**
     * Getter method for first name
     * @return first name of Person
     */
    public String getFirst() {
        return this.first;
    }

    /**
     * Setter method for Last name
     * @param last last name of Person
     */
    public void setLast(String last) {
        this.last = last;
    }

    /**
     * Getter method for last name of Person
     * @return last name of Person
     */
    public String getLast() {
        return last;
    }

    /**
     * Setter method for status of person
     * @param status status to be set
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Getter method for status of Person
     * @return status of person
     */
    public Status getStatus() {
        return this.status;
    }
}