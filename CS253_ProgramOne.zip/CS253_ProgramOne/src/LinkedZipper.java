import java.util.Collection;
import java.util.Iterator;

public class LinkedZipper<R> implements ZipperInterface<R> {

    private int size = 0;
    Node head;

    public LinkedZipper() {
        head = null;
    }

    public LinkedZipper(Collection<? extends R> list) {
        if (list == null) {
            throw new IllegalArgumentException("constructor; list has/is null");
        } else {
            for (R data : list) {
                this.add(data);
            }
        }
    }


    /**
     * This method gets the Node at the desired index
     *
     * @param index position of desired Node
     * @return Node temp is the Node that is found at desired index
     */
    private Node getNodeAt(int index) {
        Node temp = head;
        if (index >= this.size) {
            throw new IllegalArgumentException("getNode; index too far");
        } else {
            if (index != 0) {
                for (int i = 0; i < index; i++) {
                    temp = temp.next;
                }
            }
        }
        return temp;
    }

    private R getDataAt(int index) {
        Node temp = this.getNodeAt(index);
        R tempData = (R) temp.getData();
        return tempData;
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * More formally, adds the specified element q to this set if the set contains no element q2
     * such that q != null &amp;&amp; q.equals(q2). If this set already contains the element,
     * the call leaves the set unchanged and returns false. In combination with the restriction on
     * constructors, this ensures that sets never contain duplicate elements.
     *
     * @param element to be added to this set.
     * @return true if the set did not already contain the element.
     * @throws IllegalArgumentException if the element to be added is null.
     */
    public boolean add(R element) {
        boolean status = false;
        if (element == null) {
            throw new IllegalArgumentException("element added is null");
        } else {
            if (this.isEmpty()) {
                this.head = new Node(element);
                this.size++;
                status = true;
            } else {
                if (!(this.contains(element))) {
                    Node temp = this.getNodeAt(this.size - 1);
                    temp.next = new Node(element);
                    this.size++;
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Clears all data from this set.
     */
    public void clear() {
        this.head = null;
    }

    /**
     * Determine if a specific object is in the set.
     *
     * @param element object to search for
     * @return true if the object is in the set, false otherwise.
     * @throws IllegalArgumentException generated if the object to search for is null.
     */
    public boolean contains(Object element) {
        boolean status = false;
        if (element == null) {
            throw new IllegalArgumentException("contains; null element");
        } else {
            for (R data : this) {
                if (data.equals(element)) {
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Returns an iterator over the elements in this collection.  There are no
     * guarantees concerning the order in which the elements are returned
     * (unless this collection is an instance of some class that provides a
     * guarantee).
     *
     * @return an {@code Iterator} over the elements in this collection
     */
    public Iterator<R> iterator() {
        return new LinkedIterator();
    }

    /**
     * Determine if this set contains no elements.
     *
     * @return true if this set contains no elements, false otherwise.
     */
    public boolean isEmpty() {
        return this.head == null;
    }

    /**
     * Removes the specified element from this set if it is present. (This set will not contain
     * the element once the call returns.)
     *
     * @param item to be removed
     * @return true if this set contained the element (or equivalently, if this set changed as a
     * result of the call).
     * @throws IllegalArgumentException if the specified object is null.
     */
    public boolean remove(Object item) {
        boolean status = false;
        if (item == null) {
            throw new IllegalArgumentException("remove; item is null");
        }


        if (this.head.data.equals(item)) {
            this.head = this.head.next;
            this.size--;
        }

        Node temp = this.head;
        while (temp.next != null) {
            if (temp.next.data.equals(item)) {
                temp.next = temp.next.next;
                size--;
                status = true;
            } else {
                temp = temp.next;
            }
        }
        return status;
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     *
     * @return the number of elements in this set (tis cardinality).
     */
    public int size() {
        return this.size;
    }

    @Override
    public void zip(Collection<? extends R> collection) {
        //do not use in this project
    }

    @Override
    public ZipperInterface<R> unzip() {
        return null;
        //do not use in this project
    }

    /**
     * Retains only the elements in this set that are contained in the specified collection.
     * In other words, removes from this set all of its elements that are
     * not contained in the specified collection. If the specified collection is also a set, this
     * operation effectively modifies this set so that its value is the intersection of the two
     * sets.
     *
     * @param list collection containing elements to be retained in this set.
     * @return true if this set is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if the specified collection is null.
     */

    public boolean retainAll(Collection<?> list) {

        boolean status = false;
        if (list == null) {
            throw new IllegalArgumentException("retain; list is null");
        } else {
            for (Object data : this) {
                if (!(list.contains(data))) {
                    this.remove(data);
                    status = true;
                }
            }
        }
        return status;
    }

    /**
     * Returns true if this set contains all of the elements of the specified collection. If the
     * specified collection is also a set, this method returns true if it is a subset of this set.
     *
     * @param list collection to be checked for containment in this set.
     * @return true if this set contains all the elements of the specified collection.
     * @throws IllegalArgumentException If the specified collection is null or contains any null
     *                                  elements.
     */
    public boolean containsAll(Collection<?> list) {

        boolean status = true;
        if (list == null) {
            status = false;
            throw new IllegalArgumentException("containsAll; null list");
        } else {
            for (Object data : list) {
                if (!(this.contains(data))) {
                    status = false;
                }
            }
        }
        return status;
    }

    @Override
    public boolean equals(Object other) {
        boolean status = false;
        if (other instanceof Collection) {
            if (((Collection) other).size() == this.size()) {
                if (this.containsAll((Collection) other)) {
                    status = true;
                }
            }
        }
        return status;
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();
        str.append("<");
        for (int i = 0; i < this.size; i++) {
            R temp = this.getDataAt(i);
            String data = temp.toString();
            str.append(data);
            if (i < (this.size - 1)) {
                str.append(", ");
            }
        }
        str.append(">");
        return str.toString();
    }

    /**************************************************************************************/

    private class Node<R> {
        private R data;
        private Node next;

        private Node(R data) {
            this.data = data;
            this.next = null;
        }

        private Node(R data, Node node) {
            this.data = data;
            this.next = node;
        }

        private R getData() {
            return this.data;
        }

        @Override
        public String toString() {
            return this.data.toString();
        }
    }

    /*************************************************************************************/

    private class LinkedIterator implements Iterator<R> {

        private Node<R> node;

        private LinkedIterator() {
            this.node = head;
        }

        public boolean hasNext() {
            return node != null;
        }

        public R next() {
            R hold = (R) node.data;
            node = node.next;
            return hold;
        }
    }
}