public enum Status {

    SINGLE("Single"),
    WIDOWED("Widowed"),
    DIVORCED("Divorced"),
    MARRIED("Married"),
    UNASSIGNED("Unassigned");

    private final String status;

    Status(String status) {
        this.status = status;
    }

    @Override
    public String toString(){
        return this.status;
    }
}
