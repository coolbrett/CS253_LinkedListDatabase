import java.util.Collection;
/**
 * This is an interface which models a Collection that contains <b>no</b> duplicate elements. It
 * models the mathematical <i>set</i> abstraction. This interface is based on the Java
 * <code>Set</code> interface, but there are some important differences. including the addition of
 * zip and unzip functionality.
 *
 * An additional stipulation is that no constructor will construct a set containing duplicate
 * elements.
 *
 * <b> Parameters in ArrayZipper and LinkedZipper should have good descriptive names!</b>
 * @author William Kreahling
 * @author Scott Barlowe
 * @version 2019
 */
public interface ZipperInterface<Q> extends Collection<Q>{

    /**
     * Adds the specified element to this set if it is not already present.
     * More formally, adds the specified element q to this set if the set contains no element q2
     * such that q != null &amp;&amp; q.equals(q2). If this set already contains the element,
     * the call leaves the set unchanged and returns false. In combination with the restriction on
     * constructors, this ensures that sets never contain duplicate elements.
     * @param q element to be added to this set.
     * @return true if the set did not already contain the element.
     * @throws IllegalArgumentException if the element to be added is null.
     */
    public boolean add(Q q);
    /**
     * Clears all data from this set.
     */
    public void clear();
    /**
     * Determine if a specific object is in the set.
     * @param o object to search for
     * @return true if the object is in the set, false otherwise.
     * @throws IllegalArgumentException generated if the object to search for is null.
     */
    public boolean contains(Object o);
    /**
     * Returns true if this set contains all of the elements of the specified collection. If the
     * specified collection is also a set, this method returns true if it is a subset of this set.
     * @param c collection to be checked for containment in this set.
     * @return true if this set contains all the elements of the specified collection.
     * @throws IllegalArgumentException If the specified collection is null or contains any null
     * elements.
     */
    public boolean containsAll(Collection<?> c);
    /**
     * Determine if this set contains no elements.
     * @return true if this set contains no elements, false otherwise.
     */
    public boolean isEmpty();
    /**
     * Removes the specified element from this set if it is present. (This set will not contain
     * the element once the call returns.)
     * @return true if this set contained the element (or equivalently, if this set changed as a
     * result of the call).
     * @throws IllegalArgumentException if the specified object is null.
     */
    public boolean remove(Object o);
    /**
     * Adds all of the elements in the specified collection to this set if they're not already
     * present (optional operation). If the specified collection is also a set, the addAll
     * operation effectively modifies this set so that its value is the union of the two sets. The
     * behavior of this operation is undefined if the specified collection is modified while the
     * operation is in progress.
     * <b>Note: gaps in the list must be closed <i>in place</i> meaning you should not create extra
     * storage locations to remove gaps.</b>
     * @param c collection containing elements to be added to this set.
     * @return true if this set is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if collection is null or contains a null element.
     */
    public default boolean addAll(Collection<? extends Q > c) {
        throw new UnsupportedOperationException("addAll is not supported for Program 3");
    }

    /**
     * Removes from this set all of its elements that are contained in the specified collection.
     * If the specified collection is also a set, this operation effectively
     * modifies this set so that its value is the asymmetric set difference of the two sets.
     * @param c collection containing elements to be removed from this set.
     * @return true if this set is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if the specified collection is null.
     */
    public default boolean removeAll(Collection<?> c) {
        throw new UnsupportedOperationException("removeAll is not supported for Program 3");
    }
    /**
     * Retains only the elements in this set that are contained in the specified collection.
     * In other words, removes from this set all of its elements that are
     * not contained in the specified collection. If the specified collection is also a set, this
     * operation effectively modifies this set so that its value is the intersection of the two
     * sets.
     * @param c collection containing elements to be retained in this set.
     * @return true if this set is changed because of this call, false otherwise.
     * @throws IllegalArgumentException if the specified collection is null.
     */
    public boolean retainAll(Collection<?> c);

    /**
     * Returns the number of elements in this set (its cardinality).
     * @return the number of elements in this set (tis cardinality).
     */
    public int size();

    /**
     * Zips two separate sets into a single ArrayZipper such that the first item
     * in the calling object's set is the first item in the new set and the first
     * item in the set passed to the method is the second item in the new set.
     * This pattern alternates between the two sets each time adding an item to
     * the new set.  If the sets do not have the same number of items, they are
     * zipped as if they contained the same number of items with any remaining
     * items added to the end of the new set.  For example, if there are two sets
     * s1 and s2 where s1 contains "Red", "Green", "Blue", and "Brown" and s2
     * contains "Purple" and "Pink", the call
     *
     * s1.zip(s2)
     *
     * would result in s1 containing "Red", "Purple", "Green", "Pink", "Blue",
     * and "Brown", but the call
     *
     * s2.zip(s1)
     *
     * would result in s2 containing "Purple", "Red", "Pink", "Green",
     * "Blue", and "Brown".
     *
     * @param collection collection to be zipped with the calling object
     * @throws IllegalArgumentException if collection is null
     */
    public void zip(Collection<? extends Q> collection);

    /**
     * Separates the single set into two new sets such that the first item
     * in the original set becomes the first item in the calling object's new set
     * and the second item in the original set becomes the first item in the
     * returned set. This pattern is repeated until two separate sets are built.
     * The first set becomes the calling object's new set and the second set is
     * returned.  Given that a set s1 contains "Red", "Purple", "Green", "Pink",
     * "Blue", "Brown", "Yellow", the call
     *
     * s1.unzip()
     *
     * would result in s1 containing "Red", "Green", "Blue", and "Yellow". A
     * set containing "Purple", "Pink", and "Brown" would be returned.
     *
     * @return Instance of an ZipperInterface containing the items of the other
     * set (NOT the items placed in the ZipperInterface).
     */
    public ZipperInterface<Q> unzip();

    /**
     * This operation is not supported in ArrayZipper/LinkedZipper.
     * @throws UnsupportedOperationException operation is not supported.
     */
    public default Object[] toArray() {
        throw new UnsupportedOperationException("toArray is not supported for Program 3");
    }

    /**
     * This operation is not supported in ArrayZipper/LinkedZipper.
     * @throws UnsupportedOperationException operation is not supported.
     */
    public default <Q> Q[] toArray(Q[] array) {
        throw new UnsupportedOperationException("toArray is not supported for Program 3");
    }
}