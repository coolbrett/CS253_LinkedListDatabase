public class Node<R> {
    private R data;
    private Node next;

    private Node(R data) {
        this.data = data;
        this.next = null;
    }

    private Node(R data, Node node) {
        this.data = data;
        this.next = node;
    }

    private R getData(){
        return this.data;
    }

    @Override
    public String toString(){
        return this.data.toString();
    }
}
