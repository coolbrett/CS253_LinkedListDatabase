public class Person {
    /** First name */
    private String first;
    /** Last name */
    private String last;
    /** Marital Status */
    //enum??
    private Status status;
}
