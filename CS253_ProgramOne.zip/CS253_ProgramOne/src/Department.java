public enum Department {
    FACULTY("Faculty"),
    ADMIN("Admin"),
    BOTH("Faculty, Admin");

    private final String dept;

    Department(String dept) {
        this.dept = dept;
    }

    public String toString(){
        return this.dept;
    }
}
